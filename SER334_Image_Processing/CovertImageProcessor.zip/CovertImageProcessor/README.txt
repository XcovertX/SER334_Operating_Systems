To Run:

gcc CovertImageProcessor.c Image.c BMPHandler.c -o run

./run -i <image.bmp>
./run -i <image.bmp> -o test.bmp -w -r 30 -g -122 -b 90
